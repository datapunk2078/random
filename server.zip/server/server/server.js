var ws = require("nodejs-websocket");

var server = ws
  .createServer(function(connection) {
    //接收到字符串str

    broadcastLoop(connection);

    connection.on("text", function(str) {
      broadcast(str.toLocaleUpperCaseCase());
    });

    connection.on("close", function() {
      //客户端关闭
    });

    connection.on("error", function() {
      //error
    });
  })
  .listen(8001);

function broadcastLoop(connection) {
  setInterval(() => {
    connection.sendText("you got new message");
  }, 5000);
}
