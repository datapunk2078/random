/* third lib*/
import React, { useEffect, useMemo } from "react";
import { useRoutes } from "react-router-dom";
import "react-perfect-scrollbar/dist/css/styles.css";
import { IntlProvider } from "react-intl";

/*local component & methods*/
import routes from "./routes";
import "@assets/GlobalStyles.css";
import "@assets/comCover.scss";
import { useGlobalContext } from "src/context";
import { getThemeConfig } from "@lib/api";
import { AliveScope } from "react-activation";

/* language config*/
import CN from "src/language/CN.js";
import US from "src/language/US.js";

const App = () => {
  const { languageContext } = useGlobalContext();
  const language = languageContext.lang;
  let routing = useRoutes(routes(language));
  const message = useMemo(() => {
    switch (language) {
      case "en":
        return US;
      case "cn":
        return CN;
      default:
        return US;
    }
  }, [language]);

  useEffect(() => {
    getThemeConfig().then((res) => {
      console.log(res);
      if (res.data) {
        Object.keys(res.data).forEach((key) => {
          let value = res.data[key];
          document.body.style.setProperty(`--${key}`, value);
        });
      }
    });
  }, []);

  return (
    <IntlProvider messages={message} locale="fr" defaultLocale="en">
      <AliveScope> {routing}</AliveScope>
    </IntlProvider>
  );
};

export default App;
