export const STATUS_MAP = {
  0: "Pending approval",
  1: "Rejected",
  2: "Completed",
  3: "In progress",
  4: "Approved",
  5: "Cancel",
};
