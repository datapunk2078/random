/* third lib*/
import React, { useState, useEffect, useCallback } from "react";
import { FormattedMessage as Intl } from "react-intl";
import { useNavigate } from "react-router-dom";
import cn from "classnames";

/* material-ui */
import Card from "@material-ui/core/Card";
import CardActions from "@material-ui/core/CardActions";
import CardContent from "@material-ui/core/CardContent";
import ShoppingCartIcon from "@material-ui/icons/ShoppingCart";
import VisibilityIcon from "@material-ui/icons/Visibility";
import AccessTimeIcon from "@material-ui/icons/AccessTime";
import AccountCircleIcon from "@material-ui/icons/AccountCircle";

/* local components & methods */
import OnboardDataDisplay from "@comp/OnboardDataDisplay";
import styles from "./styles.module.scss";
import Model from "@basics/Modal";
import { getTableSchema } from "@lib/api";
import TableTagDisplay from "@comp/TableTag";
import Loading from "@assets/icons/Loading";
import Text from "@basics/Text";
import { sendNotify } from "src/utils/systerm-error";
import DesignPanel from "../DesignPanel";
import bigQuery from "src/assets/bigquery.png";
import hive from "src/assets/hive.png";
import Database from "src/assets/icons/Database";
import TableView from "src/assets/icons/TableView";

const CardItem = ({ cardData, resourceDetail }) => {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [tableData, setTableData] = useState();
  const [loading, setLoading] = useState(true);
  const [cartOpen, setCartOpen] = useState(false);

  const onAddCartClick = useCallback(() => {
    navigate(
      `/app/getDataAccess?type=${cardData.connection_type}&id=${cardData.project_id}&dataset=${cardData.dataset}&name=${cardData.name}`
    );
  }, [cardData, navigate]);

  const handleClose = useCallback(() => {
    setCartOpen(false);
  }, []);

  useEffect(() => {
    if (open) {
      setLoading(true);
      getTableSchema({
        projectId: cardData.project_id,
        datasetName: cardData.dataset,
        tableName: cardData.name,
      })
        .then((res) => {
          if (res.data) {
            setTableData(res.data);
            setLoading(false);
          }
        })
        .catch((e) => {
          sendNotify({ msg: e.message, status: 3, show: true });
        });
    }
  }, [resourceDetail, cardData, open]);
  return (
    <>
      <Card
        className={cn(styles.cardItem, {
          [styles[cardData.connection_type]]: cardData.connection_type,
        })}
      >
        <CardContent className={styles.cartContent}>
          <div className={styles.cardHeader}>
            <div className={styles.tableDes}>
              <div className={styles.headerTitle}>
                <Text type="title"> {cardData.name}</Text>
              </div>

              <div className={styles.hearderDes}>
                <Text type="small"> {cardData.des}</Text>
              </div>
            </div>
            <div className={styles.projectIcon}>
              {cardData.connection_type === "GCP" && (
                <img
                  className={styles.tableImg}
                  src={bigQuery}
                  alt={cardData.connection_type}
                />
              )}
              {cardData.connection_type === "Hive" && (
                <img
                  className={styles.tableImg}
                  src={hive}
                  alt={cardData.connection_type}
                />
              )}
            </div>
          </div>
          <div className={styles.mainDetail}>
            <div className={styles.tableDetail}>
              <div className={styles.cardLine}>
                <div className={styles.attrLabel}>project ID:</div>
                <div className={styles.value}>{cardData.project_id}</div>
              </div>
              <div className={styles.cardLine}>
                <div className={styles.attrLabel}>Dataset:</div>
                <div className={styles.value}>{cardData.dataset}</div>
              </div>
              <div className={styles.cardLine}>
                <div className={styles.attrLabel}>Location:</div>
                <div className={styles.value}>{cardData.location}</div>
              </div>
              <div className={cn(styles.cardLine, styles.dataOwner)}>
                <div className={styles.attrLabel}>
                  <AccountCircleIcon />:
                </div>
                <div className={styles.value}>{cardData.data_owner}</div>
              </div>
            </div>
            <div className={styles.typeIcon}>
              {cardData.type === "TABLE" && <Database />}
              {cardData.type === "VIEW" && <TableView />}
            </div>
          </div>
          <div className={styles.subTitle}>
            <Text type="subTitle">Tags</Text>
          </div>
          <div className={styles.mainDetail}>
            <div className={cn(styles.tableDetail, styles.tagsDetail)}>
              {cardData.tags && cardData.tags.length > 0 && (
                <div className={styles.tagBox}>
                  <div className={styles.tagTitle}>Table Tag</div>
                  <div className={styles.tagContainer}>
                    {cardData.tags.map((tagItem, index) => {
                      return (
                        <div
                          key={index}
                          className={styles.tagItem}
                          title={tagItem.value}
                        >
                          {tagItem.key}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
              {cardData.policyTags && cardData.policyTags.length > 0 && (
                <div className={styles.tagBox}>
                  <div className={styles.tagTitle}>Table Policy Tag</div>
                  <div className={styles.tagContainer}>
                    {cardData.policyTags.map((policyName, index) => {
                      return (
                        <div key={index} className={styles.tagItem}>
                          {policyName}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>
        </CardContent>
        <div className={styles.bottomBox}>
          <div className={styles.accessTime}>
            <AccessTimeIcon className={styles.bottomIcon} />
            <div className={styles.value}>{cardData.create_time}</div>
          </div>
          <CardActions className={styles.addToCard}>
            <VisibilityIcon
              size="small"
              onClick={() => {
                setOpen(true);
              }}
            />
            <ShoppingCartIcon onClick={onAddCartClick} size="small" />
          </CardActions>
        </div>
      </Card>

      {cartOpen && <DesignPanel open={cartOpen} handleClose={handleClose} />}

      {open && (
        <Model
          open={open}
          handleClose={() => {
            setOpen(false);
          }}
        >
          <div className={styles.modalContent}>
            {loading && (
              <div className={styles.loading}>
                <Loading />
              </div>
            )}
            {!loading && tableData && (
              <>
                <div className={styles.content}>
                  <div className={styles.contentTitle}>
                    <Text type="title">
                      <Intl id="tableTags" />
                    </Text>
                  </div>
                  <div>
                    {tableData.tags.map((tag, index) => {
                      return <TableTagDisplay key={index} tagData={tag} />;
                    })}
                  </div>
                </div>
                <div className={styles.content}>
                  <div className={styles.contentTitle}>
                    <Text type="title">
                      <Intl id="tableSchema" />
                    </Text>
                  </div>
                  <OnboardDataDisplay tableList={tableData.schema.fields} />
                </div>
              </>
            )}
          </div>
        </Model>
      )}
    </>
  );
};

export default CardItem;
