/* third lib*/
import React, { useState, useEffect, useMemo, useCallback } from "react";
import { FormattedMessage as Intl } from "react-intl";
import { useForm } from "react-hook-form";
import cn from "classnames";

/* material-ui */
import TablePagination from "@material-ui/core/TablePagination";

/* local components & methods */
import Text from "@basics/Text";
import styles from "./styles.module.scss";
import FormItem from "@comp/FormItem";
import HeadLine from "@basics/HeadLine";
import Search from "@basics/Search";
import CallModal from "@basics/CallModal";
import Loading from "@assets/icons/Loading";
import { getTableData } from "@lib/api";
import Button from "@basics/Button";
import { sendNotify } from "src/utils/systerm-error";
import CardItem from "./CardItem";

const tableForm = [
  {
    default: "",
    des: "Data Assets",
    edit: 1,
    id: "u1",
    label: "Data Assets",
    options: [
      { label: "All available data assets in Torro", value: "1" },
      { label: "All available data assets by the user ", value: "2" },
    ],
    placeholder: "GCP Project",
    style: 1,
  },
  {
    default: "",
    des: "Types",
    edit: 1,
    id: "u2",
    label: "Types",
    options: [
      { label: "GCP Projects", value: "1" },
      { label: "Use cases", value: "2" },
      { label: "Dataset", value: "3" },
      { label: "Table / View", value: "4" },
    ],
    placeholder: "",
    style: 1,
  },
  {
    default: "",
    des: "Data Governance",
    edit: 1,
    id: "u3",
    label: "Data Governance",
    options: [
      { label: "Dataset Owners", value: "1" },
      { label: "Data Governor", value: "2" },
      { label: "Region", value: "3" },
      { label: "Country", value: "4" },
    ],
    placeholder: "",
    style: 1,
  },
];

const DataDiscovery = () => {
  const { handleSubmit, control, register, reset } = useForm(); // initialise the hook

  const [formLoading, setFormLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState();
  const [tableList, setTableList] = useState([]);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(6);
  const [dataName, setDataName] = useState("");

  const [modalData, setModalData] = useState({
    open: false,
    status: 0,
    content: "",
    cb: null,
  });

  const filterTableList = useMemo(() => {
    if (!tableList) {
      return [];
    }
    let tmpList = tableList;
    return tmpList.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);
  }, [tableList, page, rowsPerPage]);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const submitHandle = (data) => {
    setSearchQuery(data);
  };

  const renderFormItem = (items, disabled) => {
    return items.map((item, index) => {
      return (
        <FormItem
          key={index}
          data={item}
          index={index}
          control={control}
          register={register}
          disabled={disabled}
        />
      );
    });
  };

  const closeModal = () => {
    setModalData({ ...modalData, open: false, cb: null });
  };

  useEffect(() => {
    if (searchQuery) {
      setFormLoading(true);
      getTableData(searchQuery)
        .then((res) => {
          setTableList(res.data);
          setFormLoading(false);
        })
        .catch((e) => {
          sendNotify({ msg: e.message, status: 3, show: true });
        });
    }
  }, [searchQuery]);

  const handleSearch = useCallback(() => {
    setFormLoading(true);
    getTableData(searchQuery)
      .then((res) => {
        setTableList(res.data);
        setFormLoading(false);
      })
      .catch((e) => {
        sendNotify({ msg: e.message, status: 3, show: true });
      });
  }, [searchQuery]);

  return (
    <div className={styles.dataDiscover}>
      <div className={styles.title}>
        <HeadLine>
          <Intl id="dataExplore" />
        </HeadLine>
      </div>
      <form
        className={styles.tableSearch}
        id="tableSearch"
        onSubmit={handleSubmit(submitHandle)}
      >
        <div className={styles.dataContainer}>
          <div className={styles.filterContianer}>
            <div className={styles.filterPanel}>
              <div className={styles.formOptions}>
                {renderFormItem(tableForm)}
              </div>
            </div>
          </div>
          <div className={styles.filterBox}>
            <div className={styles.filterItem}>
              <Search
                fullWidth
                placeholder="Search by Data name"
                value={dataName}
                onChange={(value) => {
                  setDataName(value);
                }}
                handleSearch={handleSearch}
              />
              <div className={styles.buttonWrapper}>
                <Button
                  className={styles.button}
                  type="submit"
                  variant="contained"
                >
                  <Intl id="search" />
                </Button>
                <div
                  className={styles.reset}
                  onClick={() => {
                    setDataName("");
                    reset({ u1: "", u2: "", u3: "" });
                    setTableList([]);
                    setPage(0);
                  }}
                >
                  <Text type="regular">
                    <Intl id="CLEAR" />
                  </Text>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.mainContent}>
            <div
              className={cn(styles.dataTable, {
                [styles["tableLoading"]]: formLoading,
              })}
            >
              {formLoading && <Loading></Loading>}
              {!formLoading &&
                filterTableList.map((item, index) => {
                  return <CardItem key={index} cardData={item} />;
                })}
            </div>

            <TablePagination
              rowsPerPageOptions={[6, 12, 24]}
              component="div"
              count={tableList.length}
              rowsPerPage={rowsPerPage}
              page={page}
              onChangePage={handleChangePage}
              onChangeRowsPerPage={handleChangeRowsPerPage}
            />
          </div>
        </div>
      </form>

      <CallModal
        open={modalData.open}
        content={modalData.content}
        status={modalData.status}
        buttonClickHandle={modalData.cb}
        handleClose={closeModal}
      />
    </div>
  );
};

export default DataDiscovery;
