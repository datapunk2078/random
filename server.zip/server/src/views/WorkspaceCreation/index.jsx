/* third lib*/
import React from "react";
/* material-ui */

/* local components & methods */
import styles from "./styles.module.scss";
import WorkspaceForm from "@comp/WorkspaceForm";

const WorkspaceCreation = () => {
  return (
    <div className={styles.workspaceCreation}>
      <WorkspaceForm addState={true} />
    </div>
  );
};

export default WorkspaceCreation;
